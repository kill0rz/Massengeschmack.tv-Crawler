# Massengeschmack.tv-Crawler

Durchsucht die Webseite Massengeschmack.tv nach neuen Folgen.
Es werden nur die Folgen aus dem aktuellen Abo gesucht, dafür muss bei der Umstellung des Abomodells nichts geändert werden.

Es ist ein gültiger Account zum Betrieb des Crawlers erforderlich!